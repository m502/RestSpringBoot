package com.cg.restspringboot.Exception;

public interface ErrorMessages {
	public static final String INVALID_ID = "Please enter valid id ";
}
