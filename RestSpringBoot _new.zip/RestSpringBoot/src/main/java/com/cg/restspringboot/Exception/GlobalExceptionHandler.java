package com.cg.restspringboot.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ErrorStructure> handleAdbException(ResourceNotFoundException exp,WebRequest request) {
		ErrorStructure err= new ErrorStructure( exp.getMessage(), request.getDescription(false));
		return new ResponseEntity<ErrorStructure>(err, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorStructure> handleException(Exception exp,WebRequest request) {
		ErrorStructure err= new ErrorStructure( exp.getMessage(), request.getDescription(false));
		return new ResponseEntity<ErrorStructure>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<ErrorStructure> handle(Exception exp,WebRequest request) {
		ErrorStructure err= new ErrorStructure( "Please check the url", request.getDescription(false));
		return new ResponseEntity<ErrorStructure>(err, HttpStatus.BAD_REQUEST);
	}
}
