package com.cg.restspringboot.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;


import com.cg.restspringboot.model.Employee;


@Repository

public class EmployeeDAO {
	@PersistenceContext
	private EntityManager entityManager;
	
	public void addEmployee(Employee employee) {
		entityManager.persist(employee);
	}
	public void updateEmployee(Employee employee) {
		entityManager.merge(employee);
	}
	public Employee getEmployeeById(Integer Id) {
		return entityManager.find(Employee.class,Id);
	}
	public List<Employee> getAllEmployees() {
		CriteriaQuery<Employee> query = entityManager.getCriteriaBuilder().createQuery(Employee.class);
		Root<Employee> root = query.from(Employee.class);
		query.select(root);

		return entityManager.createQuery(query).getResultList();
	}
	public boolean removeEmployee(Integer Id) {
		boolean isDeleted = false;
		Employee bean = getEmployeeById(Id);
		if (null != bean) {
			entityManager.remove(bean);
			isDeleted = true;
		}
		return isDeleted;
	}
}
