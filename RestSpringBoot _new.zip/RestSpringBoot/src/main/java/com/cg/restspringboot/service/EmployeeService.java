package com.cg.restspringboot.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.restspringboot.Exception.ErrorMessages;
import com.cg.restspringboot.Exception.ResourceNotFoundException;
import com.cg.restspringboot.dao.EmployeeDAO;
import com.cg.restspringboot.model.Employee;


@Service
public class EmployeeService {
	@Autowired
	private EmployeeDAO employeeDao;
	
	public List<Employee> getEmployees() {
		return employeeDao.getAllEmployees();
	}
	
	public Employee getEmployeeById(Integer id)throws ResourceNotFoundException {
		Employee eTemp= new Employee();
		if(id<=employeeDao.getAllEmployees().size()&&id>0) {
		  eTemp= employeeDao.getEmployeeById(id);
		}
		else {
			throw new ResourceNotFoundException(ErrorMessages.INVALID_ID);
		}
		
		
		return eTemp;
	}
	
	public void addEmployee(Employee employee) {
		Integer id= employeeDao.getAllEmployees().size()+1;
		 employee.setId(id);
		 employeeDao.addEmployee(employee);
		 
	}
	
	@Transactional
	public  void updateEmailIdEmployee(Employee employee) throws ResourceNotFoundException {
		if(employee.getId()<=employeeDao.getAllEmployees().size()&&employee.getId()>0) {
		
		Employee eTemp= new Employee();
		eTemp= employeeDao.getEmployeeById(employee.getId());
		eTemp.setEmail(employee.getEmail());
	
		
		
		
	}
		else {
			throw new ResourceNotFoundException(ErrorMessages.INVALID_ID);
		}
		}
	@Transactional
	public void deleteEmployeeById(Integer id)throws ResourceNotFoundException {
		Employee eTemp= new Employee();
		if(id<=employeeDao.getAllEmployees().size()&&id>0) {
		 employeeDao.removeEmployee(id);
		}
		else {
			throw new ResourceNotFoundException(ErrorMessages.INVALID_ID);
		}
		
		
		
	}
	
	

	
	

}
